This FW/1 directory is a complete web application and expects to live in its own webroot
if you plan to run the applications within it. To use FW/1 in a separate webroot you can
either copy the org directory to that webroot or add a mapping for /org/corfield to the
corfield folder inside the org directory (or a /org mapping to the org directory directly). 

Project home: http://fw1.riaforge.org

Documentation wiki: http://fw1.riaforge.org/wiki/

Blog: http://fw1.riaforge.org/blog/
